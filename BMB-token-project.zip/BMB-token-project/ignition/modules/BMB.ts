import { buildModule } from "@nomicfoundation/hardhat-ignition/modules";

export default buildModule("BMBModule", (m) => {
  const bmb = m.contract("BMB");

  return { bmb };
});